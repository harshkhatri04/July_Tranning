package demoabstract;

public class Rectangle extends Shape {

	@Override
	public void draw() 
	{
		 for(int r=1; r<5; r++)
         {
       System.out.print(" ");
       for(int c=1; c<7; c++)
       {
          System.out.print("*");
       }
               System.out.println();
         }
	}
}
		   