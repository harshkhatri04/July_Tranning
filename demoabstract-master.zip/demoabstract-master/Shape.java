package demoabstract;

public abstract class Shape 
{
public int height;
public int breadth;
public int getHeight() {
	return height;
}
public void setHeight(int height) {
	this.height = height;
}
public int getBreadth() {
	return breadth;
}
public void setBreadth(int breadth) {
	this.breadth = breadth;
}
public abstract void draw();
public static void main (String args[])
{
	Triangle triangle= new Triangle();
	Rectangle rectangle= new Rectangle();
	triangle.draw();
	rectangle.draw();
}

	
}

