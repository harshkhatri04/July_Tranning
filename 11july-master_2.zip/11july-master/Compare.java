
public class Compare {
	public static void main(String args[])
	{
String str1="abc";
String str2="abc";
String str3=new String("abc");
boolean val;
 val=str1.equals(str2);
 System.out.println("value is "+val);
 
 val=str1.equals(str3);
 System.out.println("value is "+val);
 
 val=str2.equals(str3);
 System.out.println("value is "+val);

System.out.println(str1==str2);
System.out.println(str1==str3);
System.out.println(str2==str3);
}
}
