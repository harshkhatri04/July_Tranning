import java.util.Comparator;
public class Comparator impliments Comparator<Car>
{
	
}