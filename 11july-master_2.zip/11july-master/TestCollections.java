import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
public class TestCollections {
	
	public static void main(String args[]){
//		
        HashMap<Person,Car>arrayList = new HashMap<Person,Car>(); 
		//Set<Car> arrayList = new HashSet<Car>();
		//,new Car()
		//Car c1=new Car("A1", "Yellow", "Maruti");
		arrayList.put(new Person("Amit",30),new Car("A1","White","Audi"));
		arrayList.put(new Person("Amit1",30),new Car("A2","White","BMW"));
		arrayList.put(new Person("Amit2",30),new Car("A3","Black","Swift"));
		arrayList.put(new Person("Amit1",30),new Car("A2","White","BMW"));
		arrayList.put(new Person("Amit2",30),new Car("A2","White","BMW"));
		
		//arrayList.add(c1);
		
		//arrayList.add(c1);
		
	//	LinkedListList<Car> linkedList=new LinkedList<Car>();
	//  set<Car> linkedList = new HashSet<Car>();
	//	Car c1=new Car("A1", "Yellow", "Maruti");
	//	linkedList.add(new Car("A1","White","Audi"));
	//	linkedList.add(new Car("A2","White","BMW"));
	//	linkedist.add(new Car("A3","Black","Swift"));
	//	linkedist.add(c1);
	//	linkedList.add(c1);
		
	//	Collections.sort(arrayList,new Comparator<Car>(){

	//		@Override
		//	public int compare(Car o1, Car o2) {
				// TODO Auto-generated method stub
		//		return o1.getColor().compareTo(o2.getColor());
		//	}
		//});
		for(Car c:arrayList)
		{
			System.out.println("Model"+c.getModel()+"Color"+c.getColor()+"Company"+c.getBrand());
			
			
		}
		System.out.println(arrayList);
		
			}
		}
