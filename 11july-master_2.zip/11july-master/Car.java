class Car {
String model;
String color;
String brand;
public Car(String model, String color, String brand)
{
	this.model=model;
	this.color=color;
	this.brand=brand;
}

public String getModel() {
	return model;
}

public void setModel(String model) {
	this.model = model;
}

public String getColor() {
	return color;
}

public void setColor(String color) {
	this.color = color;
}

public String getBrand() {
	return brand;
}

public void setBrand(String brand) {
	this.brand = brand;
}

public static void main (String args[])
	{
		Car car1=new Car("A6","red","audi");
		Car car2=new Car("A6","red","audi");
        System.out.println(car1.equals(car2));
        
	}
   public boolean equals(Car C)
   {
	   return this.model.equals(C.model)&&
	   this.color.equals(C.color)&&
	   this.brand.equals(C.brand);
   }
}



