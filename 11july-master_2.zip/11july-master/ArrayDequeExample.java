import java.util.*;

public class ArrayDequeExample {
public static void main(String args[]) {
	// creating deque and adding elements
	Deque<String> deque = new ArrayDeque<String>();
	deque.add("Ravi");
	deque.add("Vijay");
	deque.add("Ajay");
	//traversing elements
	for(String str : deque)
	{
		System.out.println(str);
	}
	//retrieve but dose not remove element
	String value = deque.peek();
	System.out.println(deque);
	System.out.println(value);
	
	//retrive and remove element
	value = deque.poll();
	System.out.println(deque);
	System.out.println(value);
	
	//insert at the tail
	deque.offer("value");
	System.out.println(deque);
	//insert at start or head
	deque.offerFirst("value1");
	System.out.println(deque);
	//insert at tail
	deque.offerLast("value2");
	System.out.println(deque);
	}
}
