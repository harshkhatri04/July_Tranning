package demotesting;

public class ArrayException {

	public Object getMassage(){
		return "Hello";
		
	}
	public int Sum (int a, int b)
	{
		int sum = a+b;
		return sum;
		
	}
	
	public void getException()
	{int arr[]=new int[2];
	System.out.println(arr[3]);
	}
	public void Sleep(int i)
	{
		Sleep(i);
	}

	}

