package demotesting;


	import junit.framework.TestCase;

	public class TestEven extends TestCase {

		Even even;

		public void setUp() {
			even = new Even();
//			System.out.println(even);
		}

		public void testCheckEven() {
			assertTrue(even.checkEven(20));
		}

		public void testCheckEvenNegative() {
			assertTrue(!even.checkEven(1));
		}

		public void testSum() {
			assertEquals(5,even.sum(2, 3));
		}	

	}




