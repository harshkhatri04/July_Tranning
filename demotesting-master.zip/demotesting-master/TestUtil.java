package demotesting;




	import org.junit.After;
	import org.junit.AfterClass;
	import org.junit.Assert;
	import org.junit.Before;
	import org.junit.BeforeClass;
	import org.junit.Ignore;
	import org.junit.Test;


	//import junit.framework.Assert;

	public class TestUtil{

		ArrayException util;
		
		@Before
		public void setup()
		{
			System.out.println("Setting");
			util = new ArrayException();
			
		}
		@BeforeClass
		public static void beforeClass()
		{
			System.out.println("Called before class");

		}
		
		
		@Test
		public void testFirst()
		{
			Assert.assertEquals(String.class, util.getMassage().getClass());

		}
		@Ignore
		public void testSum()
		{
			Assert.assertEquals(6, util.Sum(2, 3));
			System.out.println("Sum is 5");
		}
		
		@Test(timeout = 2000)
		public void testSleep()
		{
			util.Sleep(2000);
			
		}
		
		@Test(expected = ArrayIndexOutOfBoundsException.class)
		public void testExceptiom(){
			util.getException();
		}
		@After
		public void tearDown(){
			System.out.println("releasing");
			util = null;
		}
		@AfterClass
		public static void afterClass(){
		
		System.out.println("Called AfterClass");
	}
	}
		
			


