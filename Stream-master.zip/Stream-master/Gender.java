package stream;

public enum Gender
{
MALE,
FEMALE
}
