package stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import Generic.Person;

public class StreamTest {
public static void main(String args[])
{
	Person person = new Person(Gender.MALE, "name", 21);
	Person person0 = new Person(Gender.FEMALE, "name1", 22);
	Person person1 = new Person(Gender.FEMALE, "name2", 23);
	Person person2 = new Person(Gender.MALE, "name3", 24);
	
	
	
	List<Person> people = Arrays.asList(person,person0,person1,person2);
	List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,0);
	  /*  Map<Integer ,Person> map = people.stream() 
			                         .collect(Collectors.toMap((Person p)->p.getAge(), 
			                        				 (Person p)->p));
                       map.entrySet().forEach(System.out::println);*/
   //System.out.println(map);
	
	
	Map<Gender, List<Person>> mapWithNameKey =
	           people.stream()
	                 .collect(Collectors.groupingBy(Person::getGender));
	
	mapWithNameKey.entrySet().forEach(System.out::println);
	 
	System.out.println(numbers.stream()
			                 .filter(v->v>3)
			                 .filter(v->v%2 == 0)
			                 .reduce(0,(v,k)->v=v+k));
	
	     System.out.println(people.stream()
	    		  .map((Person v)->v.getName())
	                .reduce("jk",(v,k)->v.concat(k)));
	     
	     
	     System.out.println(numbers.stream()
	    		 .filter(numbers)
	    		 .reduce((numbers,k)->numbers));


	     System.out.println(numbers.stream()
	    		 .filter(value -> value%3)
	    		 .reduce((v,k)->v=v+k));
	    		 
	    		 
	    		 
	    		 
			//.merge(Gender.MALE,)
	       //System.out.println(number.entryset());
}
}
