package demoexception;

public class TestRuntimeException {

	
	public static void
}
