package demothread;
import javax.sql.rowset.spi.SyncResolver;
public class MySingleton {
	public static MySingleton ins;
    public synchronized static MySingleton getInstance(){
    	if(ins == null)
    	{
    		
    	}
    	return ins;
    
    }
    private MySingleton()
    {
    	
    }

}
