package demothread;

public class TestThread {
	public static void main(String args[])
	{
		RunnableDemo r1 = new RunnableDemo("Thread-1");
		r1.start();
		RunnableDemo r2 = new RunnableDemo("Thread1-1");
		r2.start();
	}

}
