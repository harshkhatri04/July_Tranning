package demothread;
import java.util.List;
import javax.naming.spi.DirStateFactory.Result;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
public class LambdaSimple {
	public static void main(String args[]){
		List<Person> people = Arrays.asList(
				new Person("Amit",25,Gender.Male),
				new Person("Amitab",26,Gender.Female),
		        new Person("Amitsha",27,Gender.Male),
				new Person("Amitjha",28,Gender.Male));
		//Object list;
	//Thread t = new Thread(()->System.out.println("inside Thread"));
		//t.start();
		List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		Timit.code(()->System.out.println(convertToDouble(list)));
		/*Timit.code(()->{
			list.forEach(LambdaSimple::printWithHello);
		}
	);*/
		
		/*Timit.code(()->System.out.println(list.parallelstream()
		         .filter(LambdaSimple::GT3)
		         .filter(LambdaSimple::isEven)
		         .mapToDouble(LambdaSimple::compute)
	             .sum());*/
		
		
	/*System.out.println(list.stream()
			         .filter(value -> value >3)
			         .filter(value -> value % 2 == 0)
			         .mapToDouble(value -> value*1.5)
		             .sum());*/
	} 
	public static boolean Greater(int value)
	{
		return value > 3;
		
	}
	public static boolean isEven(int value)
	{
		return value%2==0 ;
	}
	public static double compute(int value)
	{
		return value*1.5;
	}
		/*Thread t = new Thread(new Runnable(){

			@Override
			public void run() {
				for(Integer i:list)
					System.out.println(i);
			}
		});
		t.start();
		}
		}*/
		/*list.forEach(new Consumer<Integer>(){

			@Override
			public void accept(Integer t) {
				
					 System.out.println(t);
				}
			});
	}
}*/
		//list.forEach(t->System.out.println(t));
		//list.forEach(System.out::println);
		//internal iterrator using for each
		//this is cool that we need not to pass
		//any argument in sop bcz list is defining that what to print
		//list.forEach(String::valueOf);
	//	list.forEach(LambdaSimple::printWithHello);
	//}
	/*public static void printWithHello(int a){
		try{
			Thread.sleep(350);
		}catch (InterruptedException e){
			e.printStackTrace();
		}
		System.out.println("Hello" + a);*/
       
	    public static void sum(int a, int b){
			try{
				Thread.sleep(350);
			}catch (InterruptedException e){
				e.printStackTrace();
			}
			System.out.println("Hello" + a);
			
	}
}
			 