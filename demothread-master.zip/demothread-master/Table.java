package demothread;

public class Table {
	void printTable (int n){
		for(int i=1; i<=3; i++)
		{
			System.out.println("print " + n*i);
			
		
		try{
			Thread.sleep(200);
		}
		catch(Exception e){
			System.out.println(e);
		}
		}
	}
		void displayTable (int n){
			for(int i=1; i<=3; i++)
			{
				System.out.println("display" + n*i);
				
			
			try{
				Thread.sleep(200);
			}
			catch(Exception e){
				System.out.println(e);
				}
			
		}
	}
	void print(int n){
		synchronized(this){
		printTable(n);
		}
		displayTable(n);
		}
	}
		class MyThread1 extends Thread{
			Table t;
			MyThread1(Table t){
				this.t=t;
			}
			public void run(){
				t.print(5);
			}
		}
	class MyThread2 extends Thread{
		Table t;
		MyThread2(Table t){
			this.t=t;
			
		}
		public void run()
		{
			t.print(100);
			
		}
	}
	class TestSync{
		public static void main(String args[]){
			Table obj = new Table();
			MyThread1 t1 = new MyThread1(obj);
			MyThread2 t2 = new MyThread2(obj);
			t1.start();
			t2.start();
		}
	}
		
	
			
		
	


