class Hello_world{
public static void main(String a[])
	{
	System.out.println("Hello world");
	}
}