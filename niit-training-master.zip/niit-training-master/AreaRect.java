
public class AreaRect implements DemoAnonymous {
			
			@Override
			public void getDimension() {
				System.out.println("Area"+ "" +l*b);
			}
		}
