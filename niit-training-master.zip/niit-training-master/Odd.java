class Odd{
public static void main(String a[])
	{
	byte i;
	for(i=1;i<=a.length;i++)
	{
	if(i%2!=0)
	System.out.println(i);
	}
}
}