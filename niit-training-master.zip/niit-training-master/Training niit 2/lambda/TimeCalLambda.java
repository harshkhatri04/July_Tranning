
package lambda;

public class TimeCalLambda {
public static void code(Runnable r){
	long start= System.currentTimeMillis()
			try{
				r.run();
			}
	catch(Expression e){
		
	}
	start=System.currebtTimeMillis() - start;
	System.out.println
}
}
