
public class DemoArray{
	int a[]=new int[4]; 
			a[0]=5;
			a[1]=4;
			a[2]=67;
			a[3]=51;
			
			for(int i=0; i<=3;i++)
				system.out.println(i);
}
