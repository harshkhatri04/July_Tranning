package junit;

public class Util {

}
