
public class AreaSquare implements DemoAnonymous{

	@Override
	public void getDimension() {
		// TODO Auto-generated method stub
		System.out.println("Square Area");
	}

}
