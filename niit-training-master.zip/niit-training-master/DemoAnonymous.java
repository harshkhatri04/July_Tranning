
interface DemoAnonymous {
	int l=4, b=5;
	public void getDimension() {
		// TODO Auto-generated method stub
		
	}
}
