package junit;

public class TestUtil {
	SmallArrayException util;
	
	@Before
	public void setup(){
		System.out.println("setting up");
		util= new SmallArrayException();
	}
	
	@Test
	@Expected
	public void testFirst(){
		Assert.assert
	}
	
}
