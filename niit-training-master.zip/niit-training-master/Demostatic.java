class Demostatic{
static int count=0;


public static void main(String args[])
{

Demostatic a=new Demostatic();
count++;
System.out.println(count);

Demostatic b=new Demostatic();
count++;
System.out.println(count);

Demostatic c=new Demostatic();
count++;
System.out.println(count);
}
}