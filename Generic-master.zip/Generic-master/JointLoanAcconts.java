package Generic;

import java.util.ArrayList;
import java.util.List;

public class JointLoanAcconts extends LoanAcconts{
	public static void main (String []args)
	{
		//List<LoanAcconts>acconts = new ArrayList<LoanAcconts>();
		List<? extends Acconts> acconts = new ArrayList<LoanAcconts>();
		
		List<? super JointLoanAcconts>list = new ArrayList<LoanAcconts>();
	
	}

}
