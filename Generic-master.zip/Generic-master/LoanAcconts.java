package Generic;

public class LoanAcconts extends Acconts{

}
