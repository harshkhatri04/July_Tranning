package Generic;

public class GenericObject<T> {
 T object1;
 T object2;
 
 public GenericObject(T object1,  T object2){
	 super();
	 this.object1 = object1;
	 this.object2 = object2;
 }

@Override
public String toString() {
	return "GenericObject [object1=" + object1 + ", object2=" + object2 + "]";
}
 
	 
 }


