package Generic;

public class BoxPrinter<T1,T2> {
	private T1 val1; T2 val2;
	public BoxPrinter(T1 arg1 , T2 arg2)
	{
		this.val1 = arg1;
		this.val2=arg2;
	
	}
	public String toString()
	{
		return"BoxPrinter[val1= "+val1 +", val2= "+val2 +"]";
	}
}
