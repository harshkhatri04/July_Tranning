package Generic;

public class GenericObjectTest {
	public static void main (String args[]){
		GenericObject<Integer> val1= new GenericObject<Integer>(10 , 20);
		System.out.println(val1);
	
	}

}
