import java.util.Scanner;
class Print
{
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
int n=sc.nextInt();
System.out.println("enter no");
for(int i=0; i<n; i++)
{
if(i%2!=0)
{
System.out.println(i);
sc.close();
}
}
}
}