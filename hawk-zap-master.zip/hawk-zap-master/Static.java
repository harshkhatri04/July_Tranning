class Static
{
static int count=0;
public static void main(String args[])
{

Static obj=new Static();

System.out.println(count);

Static obj1=new Static();
count++;
System.out.println(count);
count++;
Static obj2=new Static();

System.out.println(count);
}
}