Responsive Web Design using Twitter Bootstrap, Spring MVC
=========================================================

The steps need to run this example is,

* Get the code from Github
* run "mvn clean tomcat:run"
* Open the brower run http://localhost:8080/air

Refer to this [blog](http://krishnasblog.com/2012/10/08/responsive-web-design-using-twitter-bootstrap-spring-mvc/) for more details.
